function startGame() {
    
    var alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
        'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
        'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

    var categories;         // Array of topics
    var chosenCategory;     // Selected catagory
    var getHint;          // Word getHint
    var word;              // Selected word
    var guess;             // Guess
    var guesses = [];      // Stored guesses
    var lives;             // Lives
    var counter;           // Count correct guesses
    var space;              // Number of spaces in word '-'

    // Get elements
    var showLives = document.getElementById("lives");
    var showCatagory = document.getElementById("catagory");
    var getHint = document.getElementById("hint");
    var showClue = document.getElementById("clue");

    //Lives set and display
    function comments() {
        showLives.innerHTML = "You have " + lives + " lives";
        if (lives < 1) {
            showLives.innerHTML = "Game Over";
        }
        for (var i = 0; i < guesses.length; i++) {
            if (counter + space === guesses.length) {
                showLives.innerHTML = "You Win!";
            }
        }
    }

    // Select Catagory
    var selectCat = function () {
        if (chosenCategory === categories[0]) {
            catagoryName.innerHTML = "The Chosen Category Is Games from 2018";
        } else if (chosenCategory === categories[1]) {
            catagoryName.innerHTML = "The Chosen Category Is Moive from 2018";
        } else if (chosenCategory === categories[2]) {
            catagoryName.innerHTML = "The Chosen Category Is the Winter Olympic";
        }
    }

    // Animate man
    function animate() {
        var drawMe = lives - 1;
        drawArray[drawMe]();
    }

    // canvas setup
    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    ctx.clearRect(0, 0, 300, 300)
    ctx.lineWidth = 2;
    ctx.moveTo(0, 300);
    ctx.lineTo(50, 250);
    ctx.lineTo(100, 300);
    ctx.moveTo(50, 250);
    ctx.lineTo(50, 25);
    ctx.moveTo(50, 75);
    ctx.lineTo(100, 25);
    ctx.moveTo(50, 25)
    ctx.lineTo(180, 25);
    ctx.lineTo(180, 50);
    ctx.moveTo(180, 75);
    ctx.stroke();

    function head() {
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(180, 80, 30, 0, 2 * Math.PI);
        ctx.stroke()
    }

    function draw(mx, my, lx, ly) {
        ctx.moveTo(mx, my)
        ctx.lineTo(lx, ly)
        ctx.stroke()
    }

    function chest() {
        draw(180, 110, 180, 200);
    }

    function rightArm() {
        draw(180, 130, 220, 170);
    }

    function leftArm() {
        draw(180, 130, 140, 170);
    }

    function rightLeg() {
        draw(180, 200, 140, 240);
    }

    function leftLeg() {
        draw(180, 200, 220, 240);
    }

    var hangman = [leftLeg, rightLeg, leftArm, rightArm, chest, head];
    
    //button setup
    
    function buttons() {
    myButtons = document.getElementById("buttons");
    letters = document.createElement('ul');

    for (var i = 0; i < alphabet.length; i++) {
      letters.id = 'alphabet';
      list = document.createElement('li');
      list.id = 'letter';
      list.innerHTML = alphabet[i];
      check();
      myButtons.appendChild(letters);
      letters.appendChild(list);
    }
  }
    // Create guesses ul
     function result() {
        wordHolder = document.getElementById("word");
        correct = document.createElement('ul');

        for (var i = 0; i < word.length; i++) {
            correct.setAttribute('id', 'my-word');
            guess = document.createElement('li');
            guess.setAttribute('class', 'guess');
            if (word[i] === "-") {
                guess.innerHTML = "-";
                space = 1;
            } else {
                guess.innerHTML = "_";
            }

            guesses.push(guess);
            wordHolder.appendChild(correct);
            correct.appendChild(guess);
        }
    }
    
    // OnClick Function check guess
    function check() {
    list.onclick = function () {
      var Guess = (this.innerHTML).toLowerCase;
      this.setAttribute("class", "active");
      this.onclick = null;
      for (var i = 0; i < word.length; i++) {
        if (word[i] === guesse) {
          guesses[i].innerHTML = guesse;
          counter += 1;
        } 
      }
      var j = (word.indexOf(guesse));
      if (j === -1) {
        lives -= 1;
        comments();
        animate();
      } else {
        comments();
      }
    }
  }
    
    // Play
    function play() {
        categories = [
            ["god of war", "monster hunter world", "red dead redemption", "far cry", "call of duty black ops", "destiny forsaken"],
            ["avengers infinity war", "mission impossible fallout", "aquaman", "maze runner the death cure", "venom", "fantastic beasts the crimes of grindelwald", "bumblebee"],
            ["biathlon", "bobsleigh", "curling", "ice hockey", "figure skating"]
        ];

        chosenCategory = categories[Math.floor(Math.random() * categories.length)];
        word = chosenCategory[Math.floor(Math.random() * chosenCategory.length)];
        word = word.replace(/\s/g, "-");
        console.log(word);
        buttons();

        guesses = [];
        lives = 7;
        counter = 0;
        space = 0;
        result();
        comments();
        selectCat();
        canvas();
    }

    play();

    // Hint

    getHint.onclick = function () {

        hints = [
          ["hack and slash", "MHW", "Cow-Boy", "This is the 5th game", "Army", "Number 2 expansion"],
          ["Marvel", "Ethan Hunt IMF Team", "Atlantis", "Labyrinth Runner", "Black Spider", "Harry Potter", "Yellow Transformers"],
          ["Skiing and Shooting", "Teams of two or four", "Slide stones on a sheet of ice", "Team sport played on ice", "Dancing on Ice"]
        ];

        var catagoryIndex = categories.indexOf(chosenCategory);
        var hintIndex = chosenCategory.indexOf(word);
        showClue.innerHTML = "Clue: - " + hints[catagoryIndex][hintIndex];
    };

    // Reset

    document.getElementById('reset').onclick = function () {
        correct.parentNode.removeChild(correct);
        letters.parentNode.removeChild(letters);
        showClue.innerHTML = "";
        context.clearRect(0, 0, 400, 400);
        play();
    }
}
