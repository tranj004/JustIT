﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureGame
{
    class Items
    {
        public string Name;
        
        public Items(string name, Player user)
        {
            Name = name;
            switch (Name)
            {
                case "heal":
                    Console.WriteLine("Using Heal Potion");
                    user.HealthPoint += 50;
                    break;
                case "stamina":
                    Console.WriteLine("Using Stamina Potion");
                    user.StaminaPoint += 50;
                    break;
            }
        }
    }
}
