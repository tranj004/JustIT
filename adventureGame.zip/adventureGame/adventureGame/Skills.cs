﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureGame
{
    class Skills
    {
        public string Name;
        public double BAttack = 1;
        public int Stamina;


        public Skills(string name)
        {
            Name = name;
            switch (Name)
            {
                case "heavy swing":
                    BAttack = 1.8;
                    Stamina = 30;
                    break;
                case "shield bash":
                    BAttack = 1.4;
                    Stamina = 30;
                    break;
                case "double strike":
                    BAttack = 2;
                    Stamina = 40;
                    break;
                case "focus":
                    BAttack = 0;
                    Stamina = -30;
                    break;
            }
        }
    }
}
