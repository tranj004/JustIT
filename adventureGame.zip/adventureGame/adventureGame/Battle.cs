﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureGame
{
    class Battle
    {
        public bool battle(Player user, Monsters mon)
        {
            Console.WriteLine($"{mon.Name} has apper");
            bool alive = true;
            bool defendingP = false;
            bool defendingM = false;
            int result1;
            int result2;
            do
            {
                Random ran = new Random();
                int sboost = ran.Next(1, 4);
                Console.WriteLine($"Your HP: {user.HealthPoint}");
                Console.WriteLine($"{mon.Name} HP: {mon.HealthPoint}");
                //debug
                if (user.Speed + sboost > mon.Speed)
                {
                    result1 = playerTurn(user, mon, defendingP);
                    if(result1 == 2)
                    {
                        break;
                    }
                    else if(result1 == 1)
                    {
                        defendingP = true;
                    }
                    //debug
                    Console.WriteLine($"Pdef {user.Defence}");
                    Console.WriteLine($"Mdef {mon.Defence}");
                    if (mon.HealthPoint > 0)
                    {
                        result2 = monsterTurn(user, mon, defendingM);
                        //debug
                        Console.WriteLine($"Pdef {user.Defence}");
                        Console.WriteLine($"Mdef {mon.Defence}");
                        if (result2 == 2)
                        {
                            break;
                        }else if(result2 == 1)
                        {
                            defendingM = true;
                        }
                    }
                    
                }
                else
                {
                    result1 = monsterTurn(user, mon, defendingM);
                    if (result1 == 2)
                    {
                        break;
                    }else if( result1 == 1)
                    {
                        defendingM = true;
                    }
                    //debug
                    Console.WriteLine($"Pdef {user.Defence}");
                    Console.WriteLine($"Mdef {mon.Defence}");
                    if (user.HealthPoint > 0)
                    {
                        result2 = playerTurn(user, mon, defendingP);
                        //debug
                        Console.WriteLine($"Pdef {user.Defence}");
                        Console.WriteLine($"Mdef {mon.Defence}");
                        if (result2 == 2)
                        {
                            break;
                        }else if(result2 == 1)
                        {
                            defendingP = true;
                        }
                    }
                    
                }
                alive = afterBattle(user, mon);
                //debug
                Console.WriteLine($"Pdef {user.Defence}");
                Console.WriteLine($"Mdef {mon.Defence}");
            } while (alive);

            if(user.HealthPoint <= 0)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        static void attackP(Player p1, Monsters m1)
        {
            Random ran = new Random();
            int boost = ran.Next(1, 5);
            int damage = (boost + p1.Attack) - m1.Defence;
            Console.WriteLine($"{p1.Name} attack dealing {damage} damages");
            m1.HealthPoint -= damage;
        }

        static void attackM(Player p1, Monsters m1)
        {
            Random ran = new Random();
            int boost = ran.Next(1, 5);
            int damage = (boost + m1.Attack) - p1.Defence;
            if (damage > 0)
            {
                Console.WriteLine($"{m1.Name} attack dealing {damage} damages");
                p1.HealthPoint -= damage;
            }
            else
            {
                Console.WriteLine($"{m1.Name} attack dealing 0 damages");
            }
        }

        static bool defenceP(Player p1)
        {
            p1.Defence = p1.Defence * 2;
            Console.WriteLine($"{p1.Name} is defending");
            return true;
            
        }
        static bool defencePStop(Player p1)
        {
            p1.Defence = p1.Defence / 2;
            return false;
        }

        static bool defenceM(Monsters m1)
        {
            m1.Defence = m1.Defence * 2;
            Console.WriteLine($"{m1.Name} is defending");
            return true;

        }
        static bool defenceMStop(Monsters m1)
        {
            m1.Defence = m1.Defence / 2;
            return false;
        }

        static int runawayP(Player p1, Monsters m1)
        {
            Random ran = new Random();
            int boost = ran.Next(1, 4);
            if((p1.Speed + boost) > m1.Speed)
            {
                Console.WriteLine($"{p1.Name} successfully runaway");
                return 2;
            }
            else
            {
                Console.WriteLine($"{p1.Name} failed to runaway");
                return 0;
            }
        }
        static int runawayM(Player p1, Monsters m1)
        {
            Random ran = new Random();
            int boost = ran.Next(1, 4);
            if (p1.Speed < (m1.Speed + boost))
            {
                Console.WriteLine($"{m1.Name} successfully runaway");
                return 2;
            }
            else
            {
                Console.WriteLine($"{m1.Name} failed to runaway");
                return 0;
            }
        }

        static int playerTurn(Player user, Monsters mon, bool defendingP)
        {
            if(defendingP == true)
            {
                defendingP = defencePStop(user);
            }
            //debug
            Console.WriteLine($"Pdef {user.Defence}");
            Console.WriteLine($"Mdef {mon.Defence}");
            Console.WriteLine($"{user.Name} Turn. Chose: A (Attack), D (Defence), R (Runaway)");
            string input = Console.ReadLine().ToUpper();
            bool mistype = false;
            do
            {
                mistype = false;
                switch (input)
                {
                    case "A":
                        attackP(user, mon);
                        return 0;
                    case "D":
                        defenceP(user);
                        return 1;
                    case "R":
                        return runawayP(user, mon);
                    default:
                        Console.WriteLine("Not an Options");
                        mistype = true;
                        return 0;
                }
            } while (mistype != false);
        }

        static int monsterTurn(Player user, Monsters mon, bool defendingM)
        {
            if (defendingM == true)
            {
                defendingM = defenceMStop(mon);
            }
            //debug
            Console.WriteLine($"Pdef {user.Defence}");
            Console.WriteLine($"Mdef {mon.Defence}");
            Random ran = new Random();
            Console.WriteLine($"{mon.Name} Turn.");
            int input = ran.Next(1, 101);
            Console.WriteLine($"random number {input}");
            bool mistype = false;
            do
            {
                mistype = false;
                if (input >= 60)
                {
                    attackM(user, mon);
                    return 0;
                }
                else if (input >= 95)
                {
                    defenceM(mon);
                    return 1;
                }
                else
                {
                    return runawayM(user, mon);
                }

            } while (mistype != false);
        }

        static bool afterBattle(Player user, Monsters mon)
        {
            if (user.HealthPoint <= 0)
            {
                Console.WriteLine("You have died");
                return false;
            }
            else if (mon.HealthPoint <= 0)
            {
                Console.WriteLine($"{mon.Name} has died");
                return false;
            }
            else
            {
                return true;
            }
        }

    }
}
