﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureGame
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Jason";
            string job = "warrior";
            Console.WriteLine("Welcome to the Labyrinth Adventure Game");
            //do
            //{
            //    Console.WriteLine("Please enter your Name: ");
            //    name = Console.ReadLine();
            //} while (name == "");
            //do
            //{
            //    Console.WriteLine("Please Chose a Job: (Warrior, Knight, Thief)");
            //    job = Console.ReadLine().ToLower();
            //    if(job == "warrior" || job == "knight" || job == "thief")
            //    {
            //        break;
            //    }
            //} while (true);
            Player p1 = new Player(name, job);
            Console.WriteLine($"Your names is {p1.Name} your job is {p1.Job} your stats are hp: {p1.HealthPoint} at: {p1.Attack} df: {p1.Defence} sp: {p1.Speed}");
            Random random = new Random();
            int ran = random.Next(1,4);
            Monsters m1 = new Monsters(ran);
            Battle bat = new Battle();
            bool fight = bat.battle(p1, m1);
            if(fight == false)
            {
                Console.WriteLine("GAME OVER!!!");
            }
            else
            {
                Console.WriteLine("You surived!");
            }
            Console.ReadLine();
            //Console.WriteLine("You are an new adventure ");
        }

        
    }
}
