﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @class
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Car> listCars = new List<Car>();
            List<Motorcycle> listMotorcycles = new List<Motorcycle>();

            Car car1 = new Car("Toyota", "Prius", 13600, "Sliver", false);
            Car car2 = new Car("Honda", "Jass", 16600.99f, "Black", false);
            Car car3 = new Car("Ferrari", "laferrari", 137600, "Red", false);

            listCars.Add(car1);
            listCars.Add(car2);
            listCars.Add(car3);

            Motorcycle motor1 = new Motorcycle("Toyota", "KYNVEW", 1300, "Sliver", false);
            Motorcycle motor2 = new Motorcycle("Honda", "CFRBBB", 1600.99f, "Black", false);
            Motorcycle motor3 = new Motorcycle("Ferrari", "SPEED", 13600, "Red", false);

            listMotorcycles.Add(motor1);
            listMotorcycles.Add(motor2);
            listMotorcycles.Add(motor3);

            bool exit = false;
            bool error = false;
            do
            {
                exit = false;
                Console.WriteLine("What do you want to do: A: (Add car), R: (Remove Car) D: (Display List) S: (Sell Vehicle) Q: (Quit) M: (Amount)");
                string userinput = Console.ReadLine().ToLower();
                switch (userinput)
                {
                    case "a":
                        Console.WriteLine("Please enter a Maker");
                        string make = Console.ReadLine();
                        Console.WriteLine("Please enter a Model");
                        string model = Console.ReadLine();
                        //try catch incase number wasn't enter into price var.
                        float price = 0;
                        do {
                            try
                            {
                                Console.WriteLine("Please enter a Price");
                                price = float.Parse(Console.ReadLine());
                                error = false;
                            }
                            catch (FormatException e)
                            {
                                Console.WriteLine(e.Message);
                                error = true;
                                
                            }
                        }while (error != false) ;
                        Console.WriteLine("Please enter a color");
                        string color = Console.ReadLine();
                        do
                        {
                            error = false;
                            Console.WriteLine("What Vehicle type is it? (C: (Car) or M (Motorcycle))");
                            string type = Console.ReadLine().ToUpper();
                            if (type == "C")
                            {
                                Car carx = new Car(make, model, price, color, false); ;
                                listCars.Add(carx);
                            }
                            else if (type == "M")
                            {
                                Motorcycle motorx = new Motorcycle(make, model, price, color, false); ;
                                listMotorcycles.Add(motorx);
                            }
                            else
                            {
                                Console.WriteLine("Not a Vehicle type");
                                error = true;
                            }
                        } while (error != false);
                        
                        break;
                    case "r":
                        do
                        {
                            error = false;
                            Console.WriteLine("What Vehicle type is it? (C: (Car) or M (Motorcycle))");
                            string type = Console.ReadLine().ToUpper();
                            if (type == "C")
                            {
                                Car.RemoveCar(listCars);
                            }
                            else if (type == "M")
                            {
                                Motorcycle.RemoveMotorcycle(listMotorcycles);
                            }
                            else
                            {
                                Console.WriteLine("Not a Vehicle type");
                                error = true;
                            }
                        } while (error != false);
                        
                        break;
                    case "d":
                        do
                        {
                            error = false;
                            Console.WriteLine("What Vehicle type is it? (C: (Car) or M (Motorcycle))");
                            string type = Console.ReadLine().ToUpper();
                            if (type == "C")
                            {
                                Car.display(listCars);
                            }
                            else if (type == "M")
                            {
                                Motorcycle.display(listMotorcycles);
                            }
                            else
                            {
                                Console.WriteLine("Not a Vehicle type");
                                error = true;
                            }
                        } while (error != false);
                        break;
                    case "s":
                        do
                        {
                            error = false;
                            Console.WriteLine("What Vehicle type is it? (C: (Car) or M (Motorcycle))");
                            string type = Console.ReadLine().ToUpper();
                            if (type == "C")
                            {
                                Car.sell(listCars);
                            }
                            else if (type == "M")
                            {
                                Motorcycle.sell(listMotorcycles);
                            }
                            else
                            {
                                Console.WriteLine("Not a Vehicle type");
                                error = true;
                            }
                        } while (error != false);
                        break;
                    case "q":
                        exit = true;
                        break;
                    case "m":
                        do
                        {
                            error = false;
                            Console.WriteLine("What Vehicle type is it? (C: (Car) or M (Motorcycle))");
                            string type = Console.ReadLine().ToUpper();
                            switch (type)
                            {
                                case "C":
                                    Console.WriteLine($"The total amount of Cars: {Car.numberOfCars}");
                                    break;
                                case "M":
                                    Console.WriteLine($"The total amount of Motorcycles: {Motorcycle.numberOfMotorcycle}");
                                    break;
                                case "A":
                                    Vehicle.numberOfVehicle = Car.numberOfCars + Motorcycle.numberOfMotorcycle;
                                    Console.WriteLine($"The total amount of Vehicle sold: {Vehicle.numberOfVehicle}");
                                    break;
                                default:
                                    Console.WriteLine("Not a Vehicle type");
                                    error = true;
                                    break;
                            }
                        } while (error != false);
                        break;
                    default:
                        Console.WriteLine("That is not an option!");
                        exit = false;
                        break;
                }
            }while(exit != true);

            
        }
    }
}
