﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @class
{
    class Vehicle
    {
        public string make;
        public string model;
        public float price;
        public string color;
        public bool sold;
        public static int numberOfVehicle = 0;

        public Vehicle(string make, string model, float price, string color, bool sold)
        {
            this.make = make;
            this.model = model;
            this.price = price;
            this.color = color;
            this.sold = sold;
            
        }

    }
    
    class Car : Vehicle
    {
        public static string type;
        public static int numberOfCars;

        public Car(string make, string model, float price, string color, bool sold) : base(make, model, price, color, sold)
        {
            type = "Car";
            sold = false;
            numberOfCars++;
        }

        static public void RemoveCar(List<Car> listCars)
        {
            Console.WriteLine("Which Model do you want to remove");
            string carRemove = Console.ReadLine();
            bool found = false;
            for (int k = 0; k < listCars.Count; k++)
            {
                if (listCars[k].model == carRemove)
                {
                    Console.WriteLine($"{listCars[k].make} {listCars[k].model} has been remove");
                    listCars.Remove(listCars[k]);
                    found = true;
                    numberOfVehicle--;
                }
            }
            if (found == false)
            {
                Console.WriteLine("Model not found");
            }
        }
        static public void display(List<Car> listCars)
        {
            foreach (Car j in listCars)
            {
                Console.WriteLine($"Make: {j.make} Model: {j.model} Price: £{j.price} Color: {j.color} Sold: {j.sold}");
            }
        }
        static public void sell(List<Car> listCars)
        {
            Console.WriteLine("Which Model do you want to sell!");
            string carSell = Console.ReadLine();
            bool found = false;
            for (int k = 0; k < listCars.Count; k++)
            {
                if (listCars[k].model == carSell)
                {
                    Console.WriteLine($"{listCars[k].make} {listCars[k].model} has been sold");
                    listCars[k].sold = true;
                    found = true;
                }
            }
            if (found == false)
            {
                Console.WriteLine("Model not found");
            }
        }
    }

    class Motorcycle : Vehicle
    {
        public static string type;
        public static int numberOfMotorcycle;

        public Motorcycle(string make, string model, float price, string color, bool sold) : base(make, model, price, color, sold)
        {
            type = "Motorcycle";
            sold = false;
            numberOfMotorcycle++;
        }

        static public void RemoveMotorcycle(List<Motorcycle> listMotorcycle)
        {
            Console.WriteLine("Which Model do you want to remove");
            string motorcycleRemove = Console.ReadLine();
            bool found = false;
            for (int k = 0; k < listMotorcycle.Count; k++)
            {
                if (listMotorcycle[k].model == motorcycleRemove)
                {
                    Console.WriteLine($"{listMotorcycle[k].make} {listMotorcycle[k].model} has been remove");
                    listMotorcycle.Remove(listMotorcycle[k]);
                    found = true;
                    numberOfVehicle--;
                }
            }
            if (found == false)
            {
                Console.WriteLine("Model not found");
            }
        }
        static public void display(List<Motorcycle> listMotorcycle)
        {
            foreach (Motorcycle j in listMotorcycle)
            {
                Console.WriteLine($"Make: {j.make} Model: {j.model} Price: £{j.price} Color: {j.color} Sold: {j.sold}");
            }
        }
        static public void sell(List<Motorcycle> listMotor)
        {
            Console.WriteLine("Which Model do you want to sell!");
            string motorSell = Console.ReadLine();
            bool found = false;
            for (int k = 0; k < listMotor.Count; k++)
            {
                if (listMotor[k].model == motorSell)
                {
                    Console.WriteLine($"{listMotor[k].make} {listMotor[k].model} has been sold");
                    listMotor[k].sold = true;
                    found = true;
                }
            }
            if (found == false)
            {
                Console.WriteLine("Model not found");
            }
        }
    }
}
