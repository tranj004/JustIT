﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace polymorphism
{
    public class printData
    {
        public void print(int number)
        {
            Console.WriteLine($"A method with interger parameter... {number * number}");
        }
        public void print(double number)
        {
            Console.WriteLine($"A method with double parameter... {number * number}");
        }
        public void print(string name)
        {
            Console.WriteLine($"A method with string parameter... {name}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            printData obj = new printData();
            obj.print("john ");
            obj.print(12);
            obj.print(5.5);

            Console.Read();
        }
    }
}
