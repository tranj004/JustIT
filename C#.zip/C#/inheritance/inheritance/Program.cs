﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            derivedClass obj = new derivedClass(8.5, 5.5);
            obj.Display();
            Console.ReadLine();
        }
    }

    public class Rectangle
    {
        public double length;
        public double width;

        public Rectangle(double len, double wid)
        {
            length = len;
            width = wid;

        }

        public double GetArea()
        {
            return length * width;
        }

        public void Display()
        {
            Console.WriteLine($"Length: {length}m Width: {width}m and Area: {GetArea()}m");
        }
    }

    class derivedClass : Rectangle
    {
        public double cost;

        public derivedClass(double l, double w) : base(l, w) { }

        public double GetCost()
        {
            cost = GetArea() * 18;
            return cost;
        }

        public void Display()
        {
            base.Display();
            Console.WriteLine($"The cost of the area is: £{GetCost()}");
        }
    }
}
