﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureGame
{
    class Monsters
    {
        public string Name { get; set; }
        public int HealthPoint;
        public int Attack;
        public int Defence;
        public int Speed;
        public bool Defending = false;
        public bool Run = false;

        public Monsters(int num)
        {
            switch (num)
            {
                case 1:
                    Name = "slime";
                    break;
                case 2:
                    Name = "goblin";
                    break;
                case 3:
                    Name = "wolf";
                    break;
            }
            
            switch (Name)
            {
                case "slime":
                    HealthPoint = 50;
                    Attack = 12;
                    Defence = 12;
                    Speed = 6;
                    break;
                case "goblin":
                    HealthPoint = 70;
                    Attack = 15;
                    Defence = 10;
                    Speed = 8;
                    break;
                case "wolf":
                    HealthPoint = 100;
                    Attack = 20;
                    Defence = 10;
                    Speed = 15;
                    break;
            }
        }
    }
}
