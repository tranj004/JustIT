﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureGame
{
    class Battle
    {
        public bool battle(Player user, Monsters mon)
        {
            Console.WriteLine($"\n{mon.Name} has apper");
            bool alive = true;
            user.Run = false;
            mon.Run = false;
            do
            {
                Random ran = new Random();
                int sboost = ran.Next(1, 11);
                user.StaminaPoint += 10;
                user.maxStamina();
                Console.WriteLine($"\nYour HP: {user.HealthPoint} Your SP: {user.StaminaPoint}");
                Console.WriteLine($"\n{mon.Name} HP: {mon.HealthPoint}");
                if (user.Speed + sboost > mon.Speed)
                {
                    playerTurn(user, mon);
                    if(user.Run == true)
                    {
                        break;
                    }
                    if (mon.HealthPoint > 0)
                    {
                        monsterTurn(user, mon);
                        if (mon.Run == true)
                        {
                            break;
                        }
                    }
                    
                }
                else
                {
                    monsterTurn(user, mon);
                    if (mon.Run == true)
                    {
                        break;
                    }
                    if (user.HealthPoint > 0)
                    {
                        playerTurn(user, mon);
                        if (user.Run == true)
                        {
                            break;
                        }
                    }
                    
                }
                alive = afterBattle(user, mon);
            } while (alive);

            if(user.HealthPoint <= 0)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        static void attackP(Player p1, Monsters m1)
        {
            Random ran = new Random();
            int boost = ran.Next(1, 11);
            int damage = (boost + p1.Attack) - m1.Defence;
            if (damage > 0)
            {
                Console.WriteLine($"\n{p1.Name} attack dealing {damage} damages");
                m1.HealthPoint -= damage;
            }
            else
            {
                Console.WriteLine($"\n{p1.Name} attack dealing 0 damages");
            }
        }

        static void attackM(Player p1, Monsters m1)
        {
            Random ran = new Random();
            int boost = ran.Next(1, 11);
            int damage = (boost + m1.Attack) - p1.Defence;
            if (damage > 0)
            {
                Console.WriteLine($"\n{m1.Name} attack dealing {damage} damages");
                p1.HealthPoint -= damage;
            }
            else
            {
                Console.WriteLine($"\n{m1.Name} attack dealing 0 damages");
            }
        }

        static void defenceP(Player p1)
        {
            p1.Defence = p1.Defence * 2;
            Console.WriteLine($"\n{p1.Name} is defending");
            p1.Defending = true;
            
        }
        static void defencePStop(Player p1)
        {
            p1.Defence = p1.Defence / 2;
            p1.Defending = false;
        }

        static void defenceM(Monsters m1)
        {
            m1.Defence = m1.Defence * 2;
            Console.WriteLine($"\n{m1.Name} is defending");
            m1.Defending = true;

        }
        static void defenceMStop(Monsters m1)
        {
            m1.Defence = m1.Defence / 2;
            m1.Defending = false;
        }

        static void runawayP(Player p1, Monsters m1)
        {
            Console.WriteLine($"\n{p1.Name} is trying to run!");
            Random ran = new Random();
            int boost = ran.Next(1, 11);
            if((p1.Speed + boost) > m1.Speed)
            {
                Console.WriteLine($"\n{p1.Name} successfully runaway");
                p1.Run = true;
            }
            else
            {
                Console.WriteLine($"\n{p1.Name} failed to runaway");
                p1.Run = false;
            }
        }
        static void runawayM(Player p1, Monsters m1)
        {
            Console.WriteLine($"\n{m1.Name} is trying to run!");
            Random ran = new Random();
            int boost = ran.Next(1, 11);
            if (p1.Speed < (m1.Speed + boost))
            {
                Console.WriteLine($"\n{m1.Name} successfully runaway");
                m1.Run = true;
            }
            else
            {
                Console.WriteLine($"\n{m1.Name} failed to runaway");
                m1.Run = false;
            }
        }

        static bool itemUse(Player user)
        {
            bool mistype = false;
            string input;
            do
            {
                user.inventory();
                Console.WriteLine("\nWhich item are you using. B (to go back)");
                input = Console.ReadLine().ToLower();
                if (input == "b" || user.Inventory.Contains(input) == true)
                {
                    mistype = false;
                }
                else
                {
                    mistype = true;
                }
            } while (mistype != false);
            if(input == "b")
            {
                return true;
            }
            Items item = new Items(input, user);
            user.Inventory.Remove(input);
            user.maxHealth();
            user.maxStamina();
            return false;
        }

        static bool skillUseP(Player p1, Monsters m1)
        {
            bool mistype = false;
            string input;
            do
            {
                p1.skillList();
                Console.WriteLine("\nWhich skill are you using. B (to go back)");
                input = Console.ReadLine().ToLower();
                if(input == "b" ||  p1.SkillsList.Contains(input) == true)
                {
                    mistype = false;
                }
                else
                {
                    mistype = true;
                }
            } while (mistype != false);
            if (input == "b")
            {
                return true;
            }
            Skills skill = new Skills(input);
            Random ran = new Random();
            if (p1.StaminaPoint > skill.Stamina)
            {
                int boost = ran.Next(1, 11);
                int damage = Convert.ToInt32(boost + (p1.Attack * skill.BAttack)) - m1.Defence;
                p1.StaminaPoint -= skill.Stamina;
                if (damage > 0)
                {
                    Console.WriteLine($"\n{p1.Name} attack dealing {damage} damages");
                    m1.HealthPoint -= damage;
                }
                else
                {
                    Console.WriteLine($"\n{p1.Name} attack dealing 0 damages");
                }
            }
            else
            {
                Console.WriteLine("\nNot enough Stamina");
            }
            return false;
        }

        static void playerTurn(Player user, Monsters mon)
        {
            if(user.Defending == true)
            {
                defencePStop(user);
            }
            bool mistype = false;
            do
            {
                Console.WriteLine($"\n{user.Name} Turn. Chose: A (Attack), D (Defence), R (Runaway), S (Skills), I (Item)");
                string input = Console.ReadLine().ToUpper();
                mistype = false;
                switch (input)
                {
                    case "A":
                        attackP(user, mon);
                        break;
                    case "D":
                        defenceP(user);
                        break;
                    case "R":
                        runawayP(user, mon);
                        break;
                    case "S":
                        mistype = skillUseP(user, mon);
                        break;
                    case "I":
                        mistype = itemUse(user);
                        break;
                    default:
                        Console.WriteLine("\nNot an Options");
                        mistype = true;
                        break;
                }
            } while (mistype == true);
        }

        static void monsterTurn(Player user, Monsters mon)
        {
            if (mon.Defending == true)
            {
                defenceMStop(mon);
            }
            Random ran = new Random();
            Console.WriteLine($"\n{mon.Name} Turn.");
            int input = ran.Next(1, 101);
            bool mistype = false;
            do
            {
                mistype = false;
                if (input <= 60)
                {
                    attackM(user, mon);
                }
                else if (input <= 95)
                {
                    defenceM(mon);
                }
                else
                {
                    runawayM(user, mon);
                }

            } while (mistype != false);
        }

        static bool afterBattle(Player user, Monsters mon)
        {
            if (user.HealthPoint <= 0)
            {
                Console.WriteLine("\nYou have died");
                return false;
            }
            else if (mon.HealthPoint <= 0)
            {
                Console.WriteLine($"\n{mon.Name} has died");
                return false;
            }
            else
            {
                return true;
            }
        }

    }
}
