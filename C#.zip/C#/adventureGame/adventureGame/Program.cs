﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureGame
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            string job;
            int battaleWon = 0;
            Console.WriteLine("Welcome to the Battle Hell Game");
            do
            {
                Console.WriteLine("Please enter your Name: ");
                name = Console.ReadLine();
            } while (name == "");
            do
            {
                Console.WriteLine("Please Chose a Job: (Warrior, Knight, Thief)");
                job = Console.ReadLine().ToLower();
                if (job == "warrior" || job == "knight" || job == "thief")
                {
                    break;
                }
            } while (true);
            Player p1 = new Player(name, job);
            p1.updateStats();
            p1.equipment();
            p1.stats();
            p1.inventory();
            p1.skillList();
            bool contin = true;
            do {
                Random random = new Random();
                int ran = random.Next(1, 4);
                Monsters m1 = new Monsters(ran);
                Battle bat = new Battle();
                bool fight = bat.battle(p1, m1);
                if (fight == false)
                {
                    Console.WriteLine("GAME OVER!!!");
                    contin = false;
                }
                else
                {
                    Console.WriteLine("You surived!\n");
                    battaleWon++;
                    do
                    {
                        
                        Console.WriteLine("Do you want to continue Y/N");
                        string con = Console.ReadLine().ToUpper();
                        if (con == "Y")
                        {
                            contin = true;
                            break;
                        }
                        else if (con == "N")
                        {
                            contin = false;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Not an Option");
                        }
                    } while (true);
                }
            } while (contin == true);
            Console.WriteLine($"You won {battaleWon} battle!");
            Console.ReadLine();
        }

        
    }
}
