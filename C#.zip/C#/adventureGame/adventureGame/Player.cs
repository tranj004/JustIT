﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureGame
{
    class Player
    {
        public string Name { get; set; }
        public string Job { get; set; }
        private int MaxHP;
        public int HealthPoint;
        private int MaxSP;
        public int StaminaPoint;
        private int BaseAttack;
        private int BaseDefence;
        private int BaseSpeed;
        public int Attack;
        public int Defence;
        public int Speed;
        public Weapons Hand1;
        public Weapons Hand2;
        public Armors Chest;
        public List<string> Inventory = new List<string>() { "heal", "heal", "heal", "heal", "heal", "stamina", "stamina" };
        public List<string> SkillsList = new List<string>() { "focus" };
        public bool Defending = false;
        public bool Run = false;

        public Player(string name, string job)
        {
            Name = name;
            Job = job;
            switch (Job)
            {
                case "warrior":
                    MaxHP = 150;
                    HealthPoint = MaxHP;
                    MaxSP = 150;
                    StaminaPoint = MaxSP;
                    BaseAttack = 10;
                    BaseDefence = 10;
                    BaseSpeed = 5;
                    SkillsList.Add("heavy swing");
                    Hand1 = new Weapons("axe");
                    Hand2 = Hand1;
                    Chest = new Armors("leather");
                    break;
                case "knight":
                    MaxHP = 200;
                    HealthPoint = MaxHP;
                    MaxSP = 100;
                    StaminaPoint = MaxSP;
                    BaseAttack = 5;
                    BaseDefence = 10;
                    BaseSpeed = 5;
                    SkillsList.Add("shield bash");
                    Hand1 = new Weapons("sword");
                    Chest = new Armors("metal");
                    Hand2 = new Weapons("shield");
                    break;
                case "thief":
                    MaxHP = 100;
                    HealthPoint = MaxHP;
                    MaxSP = 200;
                    StaminaPoint = MaxSP;
                    BaseAttack = 10;
                    BaseDefence = 5;
                    BaseSpeed = 15;
                    SkillsList.Add("double strike");
                    Hand1 = new Weapons("dagger");
                    Hand2 = new Weapons("dagger");
                    Chest = new Armors("cloth");
                    break;
            }
        }

        public void equipment()
        {
            Console.WriteLine($"Left Hand: {Hand1.Name} Right Hand: {Hand2.Name} Chest Armor: {Chest.Name}");
        }

        public void stats()
        {
            Console.WriteLine($"Your names is {Name} your job is {Job} your stats are hp: {HealthPoint} at: {Attack} df: {Defence} sp: {Speed}");
        }

        public void inventory()
        {
            Console.WriteLine("Your Items");
            string current = null;
            int cnt = 0;
            for (int l = 0; l < Inventory.Count; l++)
            {
                if (Inventory[l] != current)
                {
                    if (cnt > 0)
                    {
                        Console.WriteLine($"{current} {cnt}x\n");
                    }
                    current = Inventory[l];
                    cnt = 1;
                }
                else
                {
                    cnt++;
                }
            }
            if (cnt > 0)
            {
                Console.WriteLine($"{current} {cnt}\n");
            }
        }

        public void skillList()
        {
            Console.WriteLine("Your Skill");
            for (int l = 0; l < SkillsList.Count; l++)
            {
                Console.WriteLine($"{SkillsList[l]}\t");
            }
        }

        public void updateStats()
        {
            Attack = BaseAttack + Hand1.Attack + Hand2.Attack;
            Defence = BaseDefence + Chest.Defence + Hand2.Defence;
            Speed = BaseSpeed + Hand1.Speed + Hand2.Speed + Chest.Speed; 
        }

        public void maxHealth()
        {
            if(HealthPoint > MaxHP)
            {
                HealthPoint = MaxHP;
            }
        }

        public void maxStamina()
        {
            if (StaminaPoint > MaxSP)
            {
                StaminaPoint = MaxSP;
            }
        }
    }
}
