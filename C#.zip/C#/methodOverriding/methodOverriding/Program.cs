﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace methodOverriding
{
    public class employee
    {
        public string fname = "John";
        public string lname = "Smith";

        public virtual void fullName()
        {
            Console.WriteLine($"Your full name is {fname} {lname}");
        }
    }

    public class fullTimeEmployee : employee
    {
        string type = "Full Time";
        public override void fullName()
        {
            Console.WriteLine($"Your full name is {fname} {lname} {type}");
        }
    }

    public class partTimeEmployee : employee
    {
        string type = "Part Time";
        public override void fullName()
        {
            Console.WriteLine($"Your full name is {fname} {lname} {type}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            employee[] obj = new employee[3];
            obj[0] = new employee();
            obj[1] = new fullTimeEmployee();
            obj[2] = new partTimeEmployee();

            foreach(employee e in obj)
            {
                e.fullName();
            }

            Console.Read();
        }
    }
}
