window.onscroll = function () {
    myFunction();
    skills();
};

var navbar = document.getElementById("mainNav");
var affix = navbar.offsetTop;

function myFunction() {
    if (window.pageYOffset >= affix) {
        navbar.classList.add("affix");
    } else {
        navbar.classList.remove("affix");
    }
}

var skill = document.getElementById("skills");
const tskills = document.querySelectorAll(".tskill");
var ofTop = skill.offsetTop;

function skills() {
    if ((window.pageYOffset + 300) >= ofTop) {
        tskills.forEach(tskill => {
            tskill.classList.add("animate")
        });
    } else {
        tskills.forEach(tskill => {
            tskill.classList.remove("animate")
        });
    }
}
