window.onscroll = function() {myFunction()};

var navbar = document.getElementById("mainNav");
var affix = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= affix) {
    navbar.classList.add("affix")
  } else {
    navbar.classList.remove("affix");
  }
}
